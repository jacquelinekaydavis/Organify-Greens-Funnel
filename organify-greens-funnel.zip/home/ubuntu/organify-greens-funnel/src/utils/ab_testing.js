// A/B Testing Utility

export const getABTestGroup = (testName) => {
  const storageKey = `ab_test_${testName}`;
  let group = localStorage.getItem(storageKey);

  if (!group) {
    group = Math.random() < 0.5 ? 'A' : 'B'; // 50/50 split
    localStorage.setItem(storageKey, group);
  }
  return group;
};

export const trackABTestGroup = (testName, group) => {
  // Track A/B test group in Google Analytics
  if (typeof gtag !== 'undefined') {
    gtag('event', 'ab_test_group', {
      'event_category': 'A/B Test',
      'event_label': `${testName}_${group}`,
      'value': 1
    });
  }
  console.log(`A/B Test: ${testName} - Group ${group}`);
};

