// Email capture and analytics integration utilities
export const trackEvent = (eventName, parameters = {}) => {
  // Google Analytics 4 event tracking
  if (typeof gtag !== 'undefined') {
    gtag('event', eventName, parameters);
  }
  
  // Console log for development
  console.log('Event tracked:', eventName, parameters);
};

export const trackAffiliateClick = (linkType, productName, sourceLocation) => {
  trackEvent('affiliate_link_click', {
    link_type: linkType,
    product_name: productName,
    source_location: sourceLocation,
    value: 1
  });
};

export const trackEmailSignup = (leadMagnet, pageLocation) => {
  trackEvent('email_signup', {
    lead_magnet: leadMagnet,
    page_location: pageLocation,
    value: 1
  });
};

export const submitEmailToService = async (email, leadMagnet, source) => {
  // Track the signup event
  trackEmailSignup(leadMagnet, source);
  
  // In a real implementation, this would integrate with ConvertKit, ActiveCampaign, etc.
  // For now, we'll simulate the API call
  try {
    console.log('Submitting email to service:', { email, leadMagnet, source });
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Store in localStorage for demo purposes
    const subscribers = JSON.parse(localStorage.getItem('subscribers') || '[]');
    const newSubscriber = {
      email,
      leadMagnet,
      source,
      timestamp: new Date().toISOString(),
      id: Date.now()
    };
    subscribers.push(newSubscriber);
    localStorage.setItem('subscribers', JSON.stringify(subscribers));
    
    return { success: true, message: 'Successfully subscribed!' };
  } catch (error) {
    console.error('Email submission error:', error);
    return { success: false, message: 'Subscription failed. Please try again.' };
  }
};

export const getAffiliateLink = (product, source, campaign) => {
  // In a real implementation, this would return the actual Organify affiliate link
  // with proper tracking parameters
  const baseUrl = 'https://organifishop.com/products/green';
  const affiliateId = 'YOUR_AFFILIATE_ID'; // Replace with actual affiliate ID
  
  // Add UTM parameters for tracking
  const params = new URLSearchParams({
    utm_source: source,
    utm_medium: 'affiliate',
    utm_campaign: campaign,
    utm_content: product,
    ref: affiliateId
  });
  
  return `${baseUrl}?${params.toString()}`;
};

export const handleAffiliateClick = (linkType, productName, sourceLocation, campaign = 'default') => {
  // Track the click
  trackAffiliateClick(linkType, productName, sourceLocation);
  
  // Get the affiliate link
  const affiliateUrl = getAffiliateLink(productName, sourceLocation, campaign);
  
  // Open in new tab
  window.open(affiliateUrl, '_blank', 'noopener,noreferrer');
};

