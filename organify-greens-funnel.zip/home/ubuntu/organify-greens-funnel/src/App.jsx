import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { CheckCircle, Star, Leaf, Shield, Heart, Zap, Users, ArrowRight, Play, Download } from 'lucide-react';
import EmailCaptureForm from './components/EmailCaptureForm.jsx';
import { PrimaryAffiliateButton, SecondaryAffiliateButton } from './components/AffiliateButton.jsx';
import { trackEvent } from './utils/analytics.js';
import { getABTestGroup, trackABTestGroup } from './utils/ab_testing.js';
import './App.css';

// Import images
import heroBackground from './assets/hero-background.jpg';
import productImage from './assets/organify-greens-product.jpg';

// Home Page Component
const HomePage = () => {
  const heroHeadlineTest = getABTestGroup("hero_headline");
  React.useEffect(() => {
    trackABTestGroup("hero_headline", heroHeadlineTest);
  }, [heroHeadlineTest]);

  const headlineText = heroHeadlineTest === 'A' 
    ? 'Transform Your Health with Nature\'s Power'
    : 'Unlock Peak Vitality: The Ultimate Greens Superfood';

  const heroDescriptionTest = getABTestGroup("hero_description");
  React.useEffect(() => {
    trackABTestGroup("hero_description", heroDescriptionTest);
  }, [heroDescriptionTest]);

  const descriptionText = heroDescriptionTest === 'A'
    ? 'Discover how Organify Greens can boost your energy, reduce stress, and support healthy weight management with clinically-proven superfoods.'
    : 'Experience unparalleled energy, mental clarity, and natural detoxification with Organify Greens. Your daily dose of wellness, perfected.';

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Leaf className="h-8 w-8 text-green-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">GreenVitality</span>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <Link to="/" className="text-gray-900 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium">Home</Link>
                <Link to="/benefits" className="text-gray-500 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium">Benefits</Link>
                <Link to="/reviews" className="text-gray-500 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium">Reviews</Link>
                <Link to="/guide" className="text-gray-500 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium">Free Guide</Link>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-green-50 to-emerald-50 overflow-hidden">
        <div className="absolute inset-0 bg-cover bg-center opacity-10" style={{backgroundImage: `url(${heroBackground})`}}></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-green-100 text-green-800 hover:bg-green-200">
                #1 Recommended Greens Supplement
              </Badge>
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                {headlineText}
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                {descriptionText}
              </p>              <div className="flex flex-col sm:flex-row gap-4">
                <PrimaryAffiliateButton 
                  sourceLocation="hero_section"
                  linkType="primary_cta"
                  campaign="hero"
                />
                <SecondaryAffiliateButton 
                  sourceLocation="hero_section"
                  linkType="secondary_cta"
                  campaign="hero"
                >
                  <Play className="mr-2 h-5 w-5" />
                  Learn More About Benefits
                </SecondaryAffiliateButton>
              </div>
              <div className="mt-8 flex items-center space-x-6">
                <div className="flex items-center">
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-current" />
                    ))}
                  </div>
                  <span className="ml-2 text-gray-600">4.9/5 from 2,500+ reviews</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src={productImage} 
                alt="Organify Greens Product" 
                className="w-full max-w-md mx-auto rounded-2xl shadow-2xl"
              />
              <div className="absolute -top-4 -right-4 bg-green-600 text-white rounded-full p-3">
                <Zap className="h-6 w-6" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Lead Magnet Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Get Your FREE Ultimate Guide to Natural Energy & Stress Relief
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Discover 7 science-backed strategies to boost energy and reduce stress naturally. Plus, get exclusive tips on maximizing the benefits of superfoods.
          </p>
          <EmailCaptureForm 
            leadMagnet="Ultimate Guide to Natural Energy & Stress Relief"
            source="homepage_lead_magnet"
            className="max-w-md mx-auto"
          />
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Thousands Choose Organify Greens
            </h2>
            <p className="text-xl text-gray-600">
              Experience the transformative power of 11 superfoods in one delicious drink
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Zap className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <CardTitle>Boost Energy Naturally</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Feel energized all day without crashes. Ashwagandha and spirulina work together to support sustained energy levels.
                </p>
              </CardContent>
            </Card>
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Heart className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <CardTitle>Reduce Stress & Cortisol</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Clinical dose of 600mg Ashwagandha helps balance cortisol levels and reduce stress naturally.
                </p>
              </CardContent>
            </Card>
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Shield className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <CardTitle>Support Weight Management</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Detox your body and support healthy weight management with powerful antioxidants and adaptogens.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Social Proof Section */}
      <section className="py-16 bg-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Real Results from Real People
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex text-yellow-400 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "Life changing! I've struggled with excess belly weight for years. Since starting Organify Greens, my belly is flatter, my energy levels are up and I just feel so good!"
                </p>
                <p className="font-semibold text-gray-900">- Veronica R.</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex text-yellow-400 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "I love how this gives me sustained energy throughout the day without any jitters. The taste is amazing too - like a minty-green smoothie!"
                </p>
                <p className="font-semibold text-gray-900">- Julie B.</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex text-yellow-400 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "My stress levels have decreased significantly since I started taking this. I feel more balanced and my sleep has improved too."
                </p>
                <p className="font-semibold text-gray-900">- Michael T.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-green-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Transform Your Health?
          </h2>
          <p className="text-xl text-green-100 mb-8">
            Join thousands who have already experienced the life-changing benefits of Organify Greens.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <PrimaryAffiliateButton 
              sourceLocation="bottom_cta"
              linkType="primary_cta"
              campaign="bottom_cta"
              className="bg-white text-green-600 hover:bg-gray-100 px-8 py-3"
            />
            <SecondaryAffiliateButton 
              sourceLocation="bottom_cta"
              linkType="secondary_cta"
              campaign="bottom_cta"
              className="border-white text-white hover:bg-green-700 px-8 py-3"
            >
              Learn More About Benefits
            </SecondaryAffiliateButton>
          </div>
          <div className="mt-8 flex items-center justify-center space-x-6 text-green-100">
            <div className="flex items-center">
              <CheckCircle className="h-5 w-5 mr-2" />
              <span>60-Day Money Back Guarantee</span>
            </div>
            <div className="flex items-center">
              <CheckCircle className="h-5 w-5 mr-2" />
              <span>Free Shipping on Orders $100+</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <Leaf className="h-8 w-8 text-green-400" />
                <span className="ml-2 text-xl font-bold">GreenVitality</span>
              </div>
              <p className="text-gray-400">
                Your trusted source for natural health and wellness information.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link to="/benefits" className="hover:text-white">Benefits</Link></li>
                <li><Link to="/reviews" className="hover:text-white">Reviews</Link></li>
                <li><Link to="/guide" className="hover:text-white">Free Guide</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Contact Us</a></li>
                <li><a href="#" className="hover:text-white">FAQ</a></li>
                <li><a href="#" className="hover:text-white">Shipping Info</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Legal</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white">Affiliate Disclosure</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 GreenVitality. All rights reserved. This site contains affiliate links.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

// Benefits Page Component
const BenefitsPage = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Leaf className="h-8 w-8 text-green-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">GreenVitality</span>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <Link to="/" className="text-gray-500 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium">Home</Link>
                <Link to="/benefits" className="text-gray-900 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium">Benefits</Link>
                <Link to="/reviews" className="text-gray-500 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium">Reviews</Link>
                <Link to="/guide" className="text-gray-500 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium">Free Guide</Link>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-green-50 to-emerald-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">
            The Science Behind Organify Greens
          </h1>
          <p className="text-xl text-gray-600">
            Discover how 11 powerful superfoods work together to transform your health
          </p>
        </div>
      </section>

      {/* Detailed Benefits */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                Ashwagandha: Your Stress-Fighting Superhero
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Organify Greens contains a clinical dose of 600mg of Ashwagandha, an ancient adaptogen that has been scientifically proven to reduce cortisol levels by up to 30%.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-green-600 mr-3 mt-0.5" />
                  <span>Reduces stress and anxiety naturally</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-green-600 mr-3 mt-0.5" />
                  <span>Balances cortisol levels for better sleep</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-green-600 mr-3 mt-0.5" />
                  <span>Supports healthy weight management</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-green-600 mr-3 mt-0.5" />
                  <span>Improves focus and mental clarity</span>
                </li>
              </ul>
            </div>
            <div className="bg-green-50 p-8 rounded-2xl">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Clinical Study Results</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Stress Reduction</span>
                  <span className="font-bold text-green-600">30%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Cortisol Decrease</span>
                  <span className="font-bold text-green-600">27.9%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Energy Increase</span>
                  <span className="font-bold text-green-600">40%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Ingredient Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Leaf className="h-6 w-6 text-green-600 mr-2" />
                  Spirulina
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  A nutrient-dense blue-green algae packed with protein, vitamins, and antioxidants that support energy and immune function.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Leaf className="h-6 w-6 text-green-600 mr-2" />
                  Chlorella
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  A powerful detoxifying algae that helps remove heavy metals and toxins while supporting liver health.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Leaf className="h-6 w-6 text-green-600 mr-2" />
                  Moringa
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Known as the "miracle tree," moringa provides essential amino acids, vitamins, and minerals for overall wellness.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-green-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Experience These Benefits Yourself
          </h2>
          <p className="text-xl text-green-100 mb-8">
            Try Organify Greens risk-free with our 60-day money-back guarantee.
          </p>
          <Button size="lg" className="bg-white text-green-600 hover:bg-gray-100 px-8 py-3">
            Get Organify Greens Now
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>
    </div>
  );
};

// Reviews Page Component
const ReviewsPage = () => {
  const reviews = [
    {
      name: "Sarah M.",
      rating: 5,
      title: "Amazing Energy Boost!",
      content: "I've been taking Organify Greens for 3 months now and the difference in my energy levels is incredible. No more afternoon crashes!",
      verified: true
    },
    {
      name: "David L.",
      rating: 5,
      title: "Stress Relief That Actually Works",
      content: "As someone with a high-stress job, I was skeptical. But this really helps me feel more balanced and calm throughout the day.",
      verified: true
    },
    {
      name: "Jennifer K.",
      rating: 5,
      title: "Weight Management Support",
      content: "Combined with a healthy diet, this has really helped support my weight management goals. I feel less bloated and more energized.",
      verified: true
    },
    {
      name: "Mark R.",
      rating: 5,
      title: "Great Taste and Results",
      content: "I was worried about the taste, but it's actually really good! Mix it with almond milk and it tastes like a green smoothie.",
      verified: true
    },
    {
      name: "Lisa T.",
      rating: 5,
      title: "Better Sleep and Recovery",
      content: "Not only do I have more energy during the day, but I'm sleeping better at night. My recovery from workouts has improved too.",
      verified: true
    },
    {
      name: "Robert H.",
      rating: 5,
      title: "Digestive Health Improvement",
      content: "My digestion has improved significantly since starting this. I feel less bloated and my gut health seems much better.",
      verified: true
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Leaf className="h-8 w-8 text-green-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">GreenVitality</span>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <Link to="/" className="text-gray-500 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium">Home</Link>
                <Link to="/benefits" className="text-gray-500 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium">Benefits</Link>
                <Link to="/reviews" className="text-gray-900 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium">Reviews</Link>
                <Link to="/guide" className="text-gray-500 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium">Free Guide</Link>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-green-50 to-emerald-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">
            What Our Community Says
          </h1>
          <div className="flex items-center justify-center mb-6">
            <div className="flex text-yellow-400 mr-4">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-8 w-8 fill-current" />
              ))}
            </div>
            <span className="text-2xl font-bold text-gray-900">4.9/5</span>
            <span className="text-gray-600 ml-2">from 2,500+ verified reviews</span>
          </div>
          <p className="text-xl text-gray-600">
            Real stories from real people who transformed their health with Organify Greens
          </p>
        </div>
      </section>

      {/* Reviews Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {reviews.map((review, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex text-yellow-400">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} className="h-5 w-5 fill-current" />
                      ))}
                    </div>
                    {review.verified && (
                      <Badge className="bg-green-100 text-green-800">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Verified
                      </Badge>
                    )}
                  </div>
                  <CardTitle className="text-lg">{review.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">{review.content}</p>
                  <p className="font-semibold text-gray-900">- {review.name}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-green-600 mb-2">2,500+</div>
              <div className="text-gray-600">Happy Customers</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-green-600 mb-2">4.9/5</div>
              <div className="text-gray-600">Average Rating</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-green-600 mb-2">95%</div>
              <div className="text-gray-600">Would Recommend</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-green-600 mb-2">30 Days</div>
              <div className="text-gray-600">Average to See Results</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-green-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Join Thousands of Satisfied Customers
          </h2>
          <p className="text-xl text-green-100 mb-8">
            Start your journey to better health today with our 60-day money-back guarantee.
          </p>
          <Button size="lg" className="bg-white text-green-600 hover:bg-gray-100 px-8 py-3">
            Get Organify Greens Now
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>
    </div>
  );
};

// Free Guide Page Component
const GuidePage = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleEmailSubmit = (e) => {
    e.preventDefault();
    // Handle email submission
    console.log('Email submitted:', email);
    setSubmitted(true);
    setEmail('');
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Leaf className="h-8 w-8 text-green-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">GreenVitality</span>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <Link to="/" className="text-gray-500 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium">Home</Link>
                <Link to="/benefits" className="text-gray-500 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium">Benefits</Link>
                <Link to="/reviews" className="text-gray-500 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium">Reviews</Link>
                <Link to="/guide" className="text-gray-900 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium">Free Guide</Link>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-green-50 to-emerald-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">
            The Ultimate Guide to Natural Energy & Stress Relief
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Discover 7 science-backed strategies to boost energy and reduce stress naturally, plus exclusive tips on maximizing superfood benefits.
          </p>
          
          {!submitted ? (
            <Card className="max-w-lg mx-auto">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Get Your Free Guide</h3>
                <ul className="text-left space-y-3 mb-6">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-600 mr-3 mt-0.5" />
                    <span>7 natural energy-boosting strategies</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-600 mr-3 mt-0.5" />
                    <span>Stress reduction techniques that actually work</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-600 mr-3 mt-0.5" />
                    <span>How to maximize superfood benefits</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-600 mr-3 mt-0.5" />
                    <span>Exclusive Organify Greens discount code</span>
                  </li>
                </ul>
                <form onSubmit={handleEmailSubmit} className="space-y-4">
                  <Input
                    type="email"
                    placeholder="Enter your email address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full"
                  />
                  <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
                    <Download className="mr-2 h-4 w-4" />
                    Download Free Guide
                  </Button>
                </form>
                <p className="text-sm text-gray-500 mt-3">
                  No spam. Unsubscribe anytime. Your privacy is protected.
                </p>
              </CardContent>
            </Card>
          ) : (
            <Card className="max-w-lg mx-auto">
              <CardContent className="p-8 text-center">
                <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Thank You!</h3>
                <p className="text-gray-600 mb-6">
                  Your free guide is on its way to your inbox. Check your email in the next few minutes.
                </p>
                <Button className="bg-green-600 hover:bg-green-700">
                  Get Organify Greens Now
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </section>

      {/* Preview Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              What's Inside the Guide
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Zap className="h-6 w-6 text-green-600 mr-2" />
                  Natural Energy Boosters
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Learn about adaptogens, superfoods, and lifestyle changes that provide sustained energy without crashes.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Heart className="h-6 w-6 text-green-600 mr-2" />
                  Stress Management
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Discover science-backed techniques to reduce cortisol levels and manage stress naturally.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Leaf className="h-6 w-6 text-green-600 mr-2" />
                  Superfood Optimization
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Get insider tips on how to maximize the benefits of greens supplements and superfoods.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

// Main App Component with Router
function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/benefits" element={<BenefitsPage />} />
        <Route path="/reviews" element={<ReviewsPage />} />
        <Route path="/guide" element={<GuidePage />} />
      </Routes>
    </Router>
  );
}

export default App;

