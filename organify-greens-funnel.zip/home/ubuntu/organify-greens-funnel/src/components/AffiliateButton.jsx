import React from 'react';
import { Button } from '@/components/ui/button.jsx';
import { ExternalLink, ShoppingCart } from 'lucide-react';
import { handleAffiliateClick } from '../utils/analytics';

const AffiliateButton = ({ 
  productName = "Organify Greens",
  linkType = "cta_button",
  sourceLocation = "homepage",
  campaign = "default",
  children,
  variant = "default",
  size = "default",
  className = "",
  ...props 
}) => {
  const handleClick = (e) => {
    e.preventDefault();
    handleAffiliateClick(linkType, productName, sourceLocation, campaign);
  };

  return (
    <Button
      onClick={handleClick}
      variant={variant}
      size={size}
      className={`${className} cursor-pointer`}
      {...props}
    >
      {children}
      <ExternalLink className="h-4 w-4 ml-2" />
    </Button>
  );
};

// Specific button variants for common use cases
export const PrimaryAffiliateButton = ({ children = "Get Organify Greens Now", ...props }) => (
  <AffiliateButton
    variant="default"
    size="lg"
    className="bg-green-600 hover:bg-green-700 text-white font-semibold"
    {...props}
  >
    <ShoppingCart className="h-5 w-5 mr-2" />
    {children}
  </AffiliateButton>
);

export const SecondaryAffiliateButton = ({ children = "Learn More", ...props }) => (
  <AffiliateButton
    variant="outline"
    className="border-green-600 text-green-600 hover:bg-green-50"
    {...props}
  >
    {children}
  </AffiliateButton>
);

export const TextAffiliateLink = ({ children, className = "", ...props }) => (
  <button
    onClick={(e) => {
      e.preventDefault();
      handleAffiliateClick(props.linkType || "text_link", props.productName || "Organify Greens", props.sourceLocation || "content");
    }}
    className={`text-green-600 hover:text-green-700 underline font-medium ${className}`}
  >
    {children}
  </button>
);

export default AffiliateButton;

