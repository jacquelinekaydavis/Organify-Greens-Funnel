import React, { useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { CheckCircle, Mail, Shield, Download } from 'lucide-react';
import { submitEmailToService } from '../utils/analytics';

const EmailCaptureForm = ({ 
  leadMagnet = "Ultimate Guide to Natural Energy & Stress Relief",
  source = "homepage",
  placeholder = "Enter your email address",
  buttonText = "Download Free Guide",
  showPrivacyText = true,
  className = ""
}) => {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!email || !email.includes('@')) {
      setError('Please enter a valid email address');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const result = await submitEmailToService(email, leadMagnet, source);
      
      if (result.success) {
        setIsSubmitted(true);
        setEmail('');
      } else {
        setError(result.message);
      }
    } catch (err) {
      setError('Something went wrong. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSubmitted) {
    return (
      <Card className={`max-w-md mx-auto ${className}`}>
        <CardContent className="p-6 text-center">
          <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Thank You!
          </h3>
          <p className="text-gray-600 mb-4">
            Check your email for your free guide. It should arrive within the next few minutes.
          </p>
          <p className="text-sm text-gray-500">
            Don't forget to check your spam folder if you don't see it in your inbox.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`max-w-md mx-auto ${className}`}>
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex items-center space-x-2 mb-4">
            <Mail className="h-5 w-5 text-green-600" />
            <span className="text-sm font-medium text-gray-700">
              Get Your Free Guide
            </span>
          </div>
          
          <div>
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={placeholder}
              className="w-full"
              disabled={isSubmitting}
              required
            />
          </div>
          
          {error && (
            <p className="text-sm text-red-600">{error}</p>
          )}
          
          <Button 
            type="submit" 
            className="w-full bg-green-600 hover:bg-green-700"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <span className="flex items-center">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Subscribing...
              </span>
            ) : (
              <>
                <Download className="h-4 w-4 mr-2" />
                {buttonText}
              </>
            )}
          </Button>
          
          {showPrivacyText && (
            <div className="flex items-start space-x-2 text-xs text-gray-500">
              <Shield className="h-4 w-4 mt-0.5 flex-shrink-0" />
              <p>
                No spam. Unsubscribe anytime. Your privacy is protected.
              </p>
            </div>
          )}
        </form>
      </CardContent>
    </Card>
  );
};

export default EmailCaptureForm;

